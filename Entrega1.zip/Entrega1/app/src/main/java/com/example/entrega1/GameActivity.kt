package com.example.entrega1

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONArray
import java.util.Timer
import kotlin.concurrent.schedule

class GameActivity : AppCompatActivity() {

    private var category: String? = ""
    private lateinit var questionList: ArrayList<Question>
    private var totalQuestions = 0
    private var correctQuestions = 0
    private var currentQuestion = -1
    private var comodin = 0

    private lateinit var categoryView: TextView
    private lateinit var questionView: TextView
    private lateinit var currentView: TextView
    private lateinit var optionsArray: Array<Button>
    private lateinit var btnComodin: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_game)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val extras = intent.extras
        this.category = extras?.getString("category")
        loadQuestionsFromJSON(category)

        categoryView = findViewById(R.id.categoryView)
        categoryView.text = category?.uppercase()

        questionView = findViewById(R.id.question)
        val option1 = findViewById<Button>(R.id.option1)
        val option2 = findViewById<Button>(R.id.option2)
        val option3 = findViewById<Button>(R.id.option3)
        val option4 = findViewById<Button>(R.id.option4)
        optionsArray = arrayOf(option1, option2, option3, option4)
        btnComodin = findViewById(R.id.buttonComodin)
        currentView = findViewById(R.id.currentView)

        setNextQuestion()

        for (i in optionsArray.indices){
            optionsArray[i].setOnClickListener{ answer(i, optionsArray[i])}
        }

        btnComodin.setOnClickListener { comodin().also { btnComodin.isClickable = false } }
        }

    private fun loadQuestionsFromJSON(category: String?) {
        val fileName = "$category.json"
        val inputStream = assets.open(fileName)
        val size = inputStream.available()
        val buffer = ByteArray(size)
        inputStream.read(buffer)
        inputStream.close()
        val text = String(buffer, Charsets.UTF_8)

        val jsonArray = JSONArray(text)
        totalQuestions = jsonArray.length()
        questionList = ArrayList<Question>(totalQuestions)
        for (i in 0..<totalQuestions) {
            val jsonObject = jsonArray.getJSONObject(i)
            val question = jsonObject.getString("question")
            val optionsArray = jsonObject.getJSONArray("options")
            val options = ArrayList<String>()
            for (j in 0..<optionsArray.length())
                options.add(optionsArray.getString(j))
            val correctAnswerIndex = jsonObject.getInt("correctAnswerIndex")
            val q = Question(question, options, correctAnswerIndex)
            questionList.add(q)
        }
    }

    private fun setNextQuestion(){

        fun reiniciarColores(b: Button){
            b.setBackgroundColor(getColor(R.color.black))
        }

        currentQuestion++
        if(currentQuestion<totalQuestions) {
            questionView.text = questionList[currentQuestion].getQuestion()
            currentView.text = "${this.currentQuestion+1}/${this.totalQuestions}"
            for (i in optionsArray.indices){
                reiniciarColores(optionsArray[i])
                optionsArray[i].text = questionList[currentQuestion].getOptions()[i]
            }
        }else{
            showResults()
        }
    }

    private fun answer(ans: Int, b: Button){
        val correct = questionList[currentQuestion].getCorrectAnswerIndex()
        if ( correct == ans ){
            correctQuestions++
            b.setBackgroundColor( getColor( R.color.green ) )//verde
        } else {
            b.setBackgroundColor( getColor( R.color.red ) ) //rojo
            optionsArray[correct].setBackgroundColor( getColor( R.color.gray ) )
        }
        Timer().schedule(2000) {
           runOnUiThread { setNextQuestion() }
        }
    }

    private fun comodin(){
        this.comodin = 1
        this.setNextQuestion()
    }

    private fun showResults(){
        val promedio:Double =(correctQuestions.toDouble()/(totalQuestions-comodin).toDouble())
        this.runOnUiThread { Toast.makeText(this, "Puntaje obtenido: ${promedio*10}", Toast.LENGTH_SHORT)
                                  .show() }
        this.finish()
    }

}